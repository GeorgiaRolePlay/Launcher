<?php
// Database connection settings
$host = "localhost";      // Server name (usually 'localhost')
$user = "root";           // MySQL username
$pass = "";               // MySQL password
$dbname = "movies";  // Database name

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("❌ Database connection failed: " . $conn->connect_error);
}

// Optional: Uncomment this line to verify connection
//echo "✅ Connected successfully!";
?>

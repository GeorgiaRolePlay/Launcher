<?php
$apiKey = 'sk-8A0JvnfL2HGheYWTfy8K7mAosvzE1JCpeeCIJh6shOU';
$uploadUrl = 'https://api.videodb.io/v1/videos/upload'; // მაგალითად
$filePath = 'video/videoplayback.mp4';

// 1. Upload ვიდეოს
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $uploadUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer {$apiKey}",
    "Content-Type: multipart/form-data"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, [
    'file' => new CURLFile($filePath)
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
if (!isset($data['video_id'])) {
    die('Upload failed: '. $response);
}
$videoId = $data['video_id'];

// 2. Generate stream link
$streamUrl = "https://api.videodb.io/v1/videos/{$videoId}/stream";
$ch2 = curl_init();
curl_setopt($ch2, CURLOPT_URL, $streamUrl);
curl_setopt($ch2, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer {$apiKey}"
]);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
$response2 = curl_exec($ch2);
curl_close($ch2);

$data2 = json_decode($response2, true);
if (!isset($data2['url'])) {
    die('Stream link failed: '. $response2);
}

echo "Stream URL: " . $data2['url'];
?>

<?php
include "connect.php";

if (isset($_GET['v'])) {
    $video_id = intval($_GET['v']);
    $sql = "SELECT * FROM videos WHERE v_id = $video_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        die("ფილმი ვერ მოიძებნა!");
    }
} else {
    die("ფილმის ID ვერ მოიძებნა!");
}
?>

<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($row["v_name"]); ?> - GeoKino</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #383838;
    color: white;
}

.back-btn {
    position: fixed;
    top: 20px;
    left: 20px;
    z-index: 999;
    background-color: #ff0000;
    border: none;
    padding: 10px 20px;
    border-radius: 10px;
    cursor: pointer;
    color: white;
    font-size: 16px;
}
.back-btn:hover { background-color: #ff3333; }

.watch-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 80px 40px 40px 40px;
}

.video-player {
    width: 80%;
    max-width: 1000px;
    position: relative;
    background-color: black;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 20px rgba(255,0,0,0.5);
}

video {
    width: 100%;
    display: block;
    cursor: default;
}

.controls {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    background: rgba(0,0,0,0.7);
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    box-sizing: border-box;
    transition: all 0.3s, opacity 0.3s;
    opacity: 1;
}

.controls button {
    background: none;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
}
.controls button:hover { color: #ff0000; }

#seekBar {
    flex: 1;
    cursor: pointer;
}

.volume-container {
    position: relative;
}

.volume-slider {
    position: absolute;
    top: -120px;
    left: 50%;
    transform: translateX(-50%);
    width: 30px;
    height: 100px;
    writing-mode: bt-lr;
    -webkit-appearance: slider-vertical;
    opacity: 0;
    transition: opacity 0.3s;
    pointer-events: auto;
}

.video-info {
    text-align: center;
    margin-top: 20px;
}

.video-info h1 {
    color: #ff3333;
    margin-bottom: 10px;
}

.video-info p {
    color: #ccc;
    font-size: 16px;
}

.download-btn {
    display: inline-block;
    margin-top: 20px;
    background-color: #ff0000;
    color: white;
    text-decoration: none;
    padding: 10px 20px;
    border-radius: 10px;
    font-size: 16px;
}
.download-btn:hover { background-color: #ff3333; }
</style>
</head>
<body>

<button class="back-btn" onclick="window.location.href='index.php'">← უკან</button>

<div class="watch-container">
    <div class="video-player" id="player">
        <video id="myVideo" src="<?php echo htmlspecialchars($row["v_url"]); ?>"></video>
        <div class="controls">
            <button id="rewind">⏪ 10s</button>
            <button id="playPause">▶</button>
            <button id="forward">10s ⏩</button>
            <input type="range" id="seekBar" value="0" min="0" step="1">
            <span id="currentTime">0:00</span> / <span id="duration">0:00</span>
            <div class="volume-container">
                <button id="mute">🔊</button>
                <input type="range" id="volume" class="volume-slider" min="0" max="1" step="0.01" value="1">
            </div>
            <button id="fullScreen">⛶</button>
        </div>
    </div>

    <div class="video-info">
        <h1><?php echo htmlspecialchars($row["v_name"]); ?></h1>
        <p><?php echo htmlspecialchars($row["v_des"]); ?></p>
        <a href="<?php echo htmlspecialchars($row["v_url"]); ?>" download class="download-btn">ჩამოტვირთვა ⬇</a>
    </div>
</div>

<script>
const video = document.getElementById("myVideo");
const playPause = document.getElementById("playPause");
const seekBar = document.getElementById("seekBar");
const currentTime = document.getElementById("currentTime");
const duration = document.getElementById("duration");
const mute = document.getElementById("mute");
const volume = document.getElementById("volume");
const fullScreen = document.getElementById("fullScreen");
const rewind = document.getElementById("rewind");
const forward = document.getElementById("forward");
const volumeContainer = document.querySelector('.volume-container');
const volumeSlider = document.querySelector('.volume-slider');
const controls = document.querySelector(".controls");
const player = document.getElementById("player");
let volumeTimeout;
let mouseTimeout;

// Volume hover
volumeContainer.addEventListener('mouseenter', () => { volumeSlider.style.opacity = '1'; clearTimeout(volumeTimeout); });
volumeContainer.addEventListener('mouseleave', () => { volumeTimeout = setTimeout(() => { volumeSlider.style.opacity = '0'; }, 1000); });

// Metadata loaded
video.addEventListener("loadedmetadata", () => {
    seekBar.max = video.duration;
    duration.textContent = formatTime(video.duration);
});

// Play/pause
function togglePlayPause() {
    if(video.paused){ video.play(); playPause.textContent="⏸"; }
    else { video.pause(); playPause.textContent="▶"; }
}
playPause.addEventListener("click", togglePlayPause);
video.addEventListener("click", togglePlayPause);

// Time update
video.addEventListener("timeupdate", () => {
    seekBar.value = video.currentTime;
    currentTime.textContent = formatTime(video.currentTime);
});

// Seek
seekBar.addEventListener("input", () => { video.currentTime = seekBar.value; });

// Mute
mute.addEventListener("click", () => {
    video.muted = !video.muted;
    mute.textContent = video.muted ? "🔇" : "🔊";
});

// Volume
volume.addEventListener("input", () => {
    video.volume = volume.value;
    video.muted = volume.value==0;
    mute.textContent = video.muted ? "🔇" : "🔊";
});

// Rewind / Forward
rewind.addEventListener("click", () => { video.currentTime = Math.max(0, video.currentTime - 10); });
forward.addEventListener("click", () => { video.currentTime = Math.min(video.duration, video.currentTime + 10); });

// Fullscreen (wrapper)
fullScreen.addEventListener("click", () => {
    if (player.requestFullscreen) player.requestFullscreen();
    else if (player.webkitRequestFullscreen) player.webkitRequestFullscreen();
});

// Show controls in fullscreen
document.addEventListener("fullscreenchange", () => {
    if(document.fullscreenElement){
        controls.style.position = "fixed";
        controls.style.bottom = "20px";
        controls.style.left = "50%";
        controls.style.transform = "translateX(-50%)";
        controls.style.width = "auto";
        controls.style.zIndex = "10000";

        video.style.width = "100%";
        video.style.height = "100%";
        video.style.objectFit = "contain";

        startAutoHide();
    } else {
        controls.style.position = "absolute";
        controls.style.bottom = "0";
        controls.style.left = "0";
        controls.style.transform = "none";
        controls.style.width = "100%";

        video.style.width = "";
        video.style.height = "";
        video.style.objectFit = "cover";

        stopAutoHide();
        controls.style.opacity = "1";
        document.body.style.cursor = "";
    }
});

// Format time
function formatTime(seconds) {
    const hrs = Math.floor(seconds / 3600);
    const min = Math.floor((seconds % 3600) / 60);
    const sec = Math.floor(seconds % 60);

    const formattedHours = hrs > 0 ? `${hrs}:` : "0:";
    const formattedMinutes = min < 10 ? `0${min}` : `${min}`;
    const formattedSeconds = sec < 10 ? `0${sec}` : `${sec}`;

    return `${formattedHours}${formattedMinutes}:${formattedSeconds}`;
}


// Auto-hide controls and cursor in fullscreen
function startAutoHide() {
    document.body.style.cursor = "default"; // მაუსის ქონა
    resetAutoHide();
    player.addEventListener("mousemove", resetAutoHide);
}

function stopAutoHide() {
    clearTimeout(mouseTimeout);
    player.removeEventListener("mousemove", resetAutoHide);
    document.body.style.cursor = "";
}

function resetAutoHide() {
    controls.style.opacity = "1";
    video.style.cursor = "default";
    clearTimeout(mouseTimeout);
    mouseTimeout = setTimeout(() => {
        controls.style.opacity = "0";
        video.style.cursor = "none";
    }, 3000);
}

// Start auto-hide for normal view
player.addEventListener("mousemove", () => {
    controls.style.opacity = "1";
    video.style.cursor = "default";
    clearTimeout(mouseTimeout);
    mouseTimeout = setTimeout(() => {
        controls.style.opacity = "0"; // ნორმალურ view-ში მაუსი არ ქრება
        video.style.cursor = "none";
    }, 3000);
});

</script>

</body>
</html>

<?php 
include "header.php";
include "connect.php"; 
$sql = "SELECT * FROM videos";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ka">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>GeoKino</title>
</head>
<body>
<div class="movies-container">
    <?php while($row = $result->fetch_assoc()) { 
        // აღწერის შემოკლება 170 სიმბოლომდე
        $short_des = mb_substr($row["v_des"], 0, 150, "UTF-8"); 
        if (mb_strlen($row["v_des"], "UTF-8") > 150) {
            $short_des .= " ..."; // თუ აღემატება 150-ს, დავამატოთ "..."
        }
    ?>
    <div class="movie" onclick="location.href='watch.php?v=<?php echo $row["v_id"];?>&name=<?php echo urlencode($row["v_name"]);?>'">
        <div class="movie-image">
            <img src="<?php echo $row["v_img"]; ?>" alt="">
        </div>
        <div class="movie-name">
            <h3><?php echo htmlspecialchars($row["v_name"]); ?></h3>
        </div>
        <div class="movie-des">
            <?php echo htmlspecialchars($short_des); ?>
        </div>
    </div>
    <?php } ?>
</div>

</body>
</html>
